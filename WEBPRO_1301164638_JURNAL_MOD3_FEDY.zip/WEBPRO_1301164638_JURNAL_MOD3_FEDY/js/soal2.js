function validasi() {
	var nama = document.getElementById("nama").value;
	var email = document.getElementById("email").value;
	var alamat = document.getElementById("alamat").value;
	if(nama != "" && email != "" && alamat != ""){
		alert("Halo " + nama + " selamat datang !");
	} else {
		alert("Anda Harus mengisi data dengan lengkap!");
	}
}

function background(){
	document.body.style.background="#f3f3f3 url('image.jpg')"
}

function font(){
	var telkom = document.getElementById("telkom").st
}
// write your code here
// tulis kodingan disini
